//CS33 Assignent1 Yuxin Sun
//to print a string, integer, floating point number and char
#include<stdio.h>
#include<math.h>

int main(int argc, char*argv[])
{
	//printf function
	//A string
   char test[]="It is a string";
   printf("The string is:%s\n",test);
   //A integer
   printf("The integer is: %d\n",10);
   //A floating point number
   printf("The floatint point number (use pai) is: %f\n",M_PI);
   //A char
   printf("The char is :%c\n",'A');
   return 0;
}
